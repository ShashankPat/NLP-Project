# Mental Health Meme Classification
This repository contains code to implement a multimodal framework for mental health meme classification, based on the paper "Figurative-cum-Commonsense Knowledge Infusion for Multimodal Mental Health Meme Classification". The framework leverages OCR text, figurative reasoning (using a placeholder module or GPT-4 in a full implementation), and a Retrieval-Augmented Generation (RAG) module for fusing commonsense knowledge with textual features, followed by classification.

## Overview
The system processes meme images to extract text via OCR and uses a figurative reasoning module to generate enriched textual interpretations. The OCR text and reasoning are then fused using a Retrieval-Augmented Generation (RAG) module, and a classifier predicts the mental health symptom (e.g., anxiety or depression). Two datasets are used:

- AxiOM: A dataset for anxiety meme classification.
- RESTORE: A dataset for depressive symptom classification.

## Requirements
Make sure you have the following installed:
- Python 3.7+
- PyTorch (with CUDA support if available)
- pandas
- Pillow
- pytesseract
- sentence-transformers
- transformers
- scikit-learn

## Dataset Preparation
### Anxiety Dataset:
The training dataset should be a CSV file (anxiety_train.csv) with columns:
- sample_id: the image file name (without extension).
- meme_anxiety_categories: the corresponding anxiety symptom label as a string.

The corresponding images should be placed in a folder (e.g., anxiety_train_image) with a .jpg extension.

### Depression Dataset:
For the depression dataset, JSON files (e.g., train.json and test.json) are expected to contain:
- sample_id: the image file name (without extension).
- meme_depressive_categories: a list of depressive symptom labels.

The images should be stored in folders (e.g., train and test) with a .jpeg extension.

## Training Instructions
### Set Up Your Environment:
Install all required Python packages using pip:

pip install torch torchvision pandas pillow pytesseract sentence-transformers transformers scikit-learn

### Adjust File Paths:
Modify the file paths in the training script to match your dataset location.

### Run the Training Script:
Execute the training script to train the model over multiple epochs. For example:

python filename.py

### Model Output:
The script prints batch losses and average loss per epoch. Optionally, you can add code to save model checkpoints.

